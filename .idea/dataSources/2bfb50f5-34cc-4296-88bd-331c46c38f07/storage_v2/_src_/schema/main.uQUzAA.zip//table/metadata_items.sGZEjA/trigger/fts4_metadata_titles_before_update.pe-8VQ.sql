CREATE TRIGGER fts4_metadata_titles_before_update BEFORE UPDATE ON metadata_items BEGIN DELETE FROM fts4_metadata_titles WHERE docid=old.rowid; END;

