CREATE TRIGGER fts4_tag_titles_after_insert AFTER INSERT ON tags BEGIN INSERT INTO fts4_tag_titles(docid, tag) VALUES(new.rowid, new.tag); END;

