CREATE TRIGGER fts4_metadata_titles_after_update AFTER UPDATE ON metadata_items BEGIN INSERT INTO fts4_metadata_titles(docid, title, title_sort, original_title) VALUES(new.rowid, new.title, new.title_sort, new.original_title); END;

