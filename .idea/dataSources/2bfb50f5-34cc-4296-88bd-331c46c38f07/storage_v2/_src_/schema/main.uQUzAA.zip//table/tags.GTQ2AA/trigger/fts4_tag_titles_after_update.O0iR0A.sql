CREATE TRIGGER fts4_tag_titles_after_update AFTER UPDATE ON tags BEGIN INSERT INTO fts4_tag_titles(docid, tag) VALUES(new.rowid, new.tag); END;

