CREATE TRIGGER fts4_tag_titles_before_update BEFORE UPDATE ON tags BEGIN DELETE FROM fts4_tag_titles WHERE docid=old.rowid; END;

